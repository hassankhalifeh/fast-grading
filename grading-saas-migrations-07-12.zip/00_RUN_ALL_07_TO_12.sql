-- =====================================================================
-- 00_RUN_ALL_07_TO_12.sql
-- تجميع تنفيذي واحد للملفات 07→12 بالترتيب الصحيح، مطابق لما نُفّذ
-- فعلياً على قاعدة Supabase (rpxfbbznsctoyevfcvyu / Fast Grading)
-- =====================================================================

-- =====================================================================
-- 07_bulk_import.sql
-- آلية استيراد جماعي (Bulk Import) للطلاب / المعلمين / الصفوف
-- مع كشف التصادم، شاشة مراجعة قبل الاعتماد، وأرشفة المسميات القديمة
--
-- مصحَّح ليطابق السكيما الحقيقية: capabilities مفتاحها key نصي وليس
-- id/code، has_capability() توخذ وسيط واحد (اسم الصلاحية) وتتحقق من
-- auth.uid() الجلسة الحالية مباشرة، و audit_logs تتطلب account_id +
-- action_type من ENUM محدود (insert/update/delete/login/grade_window_toggle)
-- + عمودي old/new_value من نوع JSONB وليس TEXT.
-- =====================================================================

-- دالة مساعدة إضافية (لا تحل محل current_app_user() الموجودة أصلاً،
-- بترجع الـ id فقط للراحة ببقية ملفات 07-11)
CREATE OR REPLACE FUNCTION current_app_user_id()
RETURNS UUID AS $$
    SELECT id FROM app_users WHERE auth_uid = auth.uid() LIMIT 1;
$$ LANGUAGE sql STABLE;

CREATE EXTENSION IF NOT EXISTS pg_trgm;

INSERT INTO capabilities (key, label_ar, category)
VALUES ('records.import_manage', 'استيراد ومراجعة واعتماد ملفات الطلاب/المعلمين/الصفوف الجماعية', 'Admin')
ON CONFLICT (key) DO NOTHING;

CREATE TYPE import_entity_enum AS ENUM ('student', 'teacher', 'class');
CREATE TYPE import_batch_status_enum AS ENUM ('pending_review', 'committed', 'cancelled');
CREATE TYPE import_row_match_enum AS ENUM ('new', 'identical', 'conflict');
CREATE TYPE import_row_action_enum AS ENUM ('pending', 'accept_new', 'keep_old', 'manual_edit', 'ignore');

CREATE TABLE import_batches (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id      UUID NOT NULL REFERENCES accounts(id),
    entity_type     import_entity_enum NOT NULL,
    file_name       TEXT,
    uploaded_by     UUID NOT NULL REFERENCES app_users(id),
    status          import_batch_status_enum NOT NULL DEFAULT 'pending_review',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    committed_at    TIMESTAMPTZ
);

CREATE TABLE import_staging_students (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_id            UUID NOT NULL REFERENCES import_batches(id) ON DELETE CASCADE,
    raw_full_name       TEXT NOT NULL,
    raw_class_section_id UUID REFERENCES class_sections(id),
    raw_extra           JSONB DEFAULT '{}'::jsonb,
    match_status        import_row_match_enum NOT NULL DEFAULT 'new',
    matched_student_id  UUID REFERENCES students(id),
    similarity_score    NUMERIC(4,3),
    resolved_action     import_row_action_enum NOT NULL DEFAULT 'pending',
    resolved_final_name TEXT,
    resolved_by         UUID REFERENCES app_users(id),
    resolved_at         TIMESTAMPTZ
);

CREATE TABLE import_staging_teachers (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_id            UUID NOT NULL REFERENCES import_batches(id) ON DELETE CASCADE,
    raw_full_name       TEXT NOT NULL,
    raw_email           TEXT,
    raw_phone           TEXT,
    match_status        import_row_match_enum NOT NULL DEFAULT 'new',
    matched_user_id     UUID REFERENCES app_users(id),
    similarity_score    NUMERIC(4,3),
    resolved_action     import_row_action_enum NOT NULL DEFAULT 'pending',
    resolved_final_name TEXT,
    resolved_final_email TEXT,
    resolved_final_phone TEXT,
    resolved_by         UUID REFERENCES app_users(id),
    resolved_at         TIMESTAMPTZ
);

CREATE TABLE import_staging_classes (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_id            UUID NOT NULL REFERENCES import_batches(id) ON DELETE CASCADE,
    raw_school_id       UUID REFERENCES schools(id),
    raw_grade_level     TEXT NOT NULL,
    raw_section_label   TEXT NOT NULL,
    match_status        import_row_match_enum NOT NULL DEFAULT 'new',
    matched_class_id    UUID REFERENCES class_sections(id),
    resolved_action     import_row_action_enum NOT NULL DEFAULT 'pending',
    resolved_by         UUID REFERENCES app_users(id),
    resolved_at         TIMESTAMPTZ
);

CREATE TABLE name_change_log (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id          UUID NOT NULL REFERENCES accounts(id),
    entity_type         import_entity_enum NOT NULL,
    entity_id           UUID NOT NULL,
    field_name          TEXT NOT NULL,
    old_value           TEXT,
    new_value           TEXT,
    changed_by          UUID NOT NULL REFERENCES app_users(id),
    batch_id            UUID REFERENCES import_batches(id),
    changed_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    review_window_ends  TIMESTAMPTZ NOT NULL DEFAULT (now() + INTERVAL '60 days')
);

CREATE OR REPLACE FUNCTION analyze_student_import_batch(p_batch_id UUID)
RETURNS VOID AS $$
DECLARE
    v_row RECORD;
    v_best_match RECORD;
BEGIN
    FOR v_row IN
        SELECT * FROM import_staging_students WHERE batch_id = p_batch_id
    LOOP
        SELECT s.id, s.full_name,
               similarity(lower(trim(s.full_name)), lower(trim(v_row.raw_full_name))) AS sim
        INTO v_best_match
        FROM students s
        JOIN class_enrollments ce ON ce.student_id = s.id AND ce.class_section_id = v_row.raw_class_section_id
        ORDER BY sim DESC
        LIMIT 1;

        IF v_best_match.id IS NULL THEN
            UPDATE import_staging_students SET match_status = 'new' WHERE id = v_row.id;
        ELSIF v_best_match.sim >= 0.999 THEN
            UPDATE import_staging_students
            SET match_status = 'identical', matched_student_id = v_best_match.id, similarity_score = v_best_match.sim
            WHERE id = v_row.id;
        ELSIF v_best_match.sim >= 0.55 THEN
            UPDATE import_staging_students
            SET match_status = 'conflict', matched_student_id = v_best_match.id, similarity_score = v_best_match.sim
            WHERE id = v_row.id;
        ELSE
            UPDATE import_staging_students SET match_status = 'new' WHERE id = v_row.id;
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION analyze_teacher_import_batch(p_batch_id UUID)
RETURNS VOID AS $$
DECLARE
    v_row RECORD;
    v_matched_id UUID;
    v_matched_name TEXT;
BEGIN
    FOR v_row IN
        SELECT * FROM import_staging_teachers WHERE batch_id = p_batch_id
    LOOP
        SELECT au.id, au.full_name INTO v_matched_id, v_matched_name
        FROM app_users au
        WHERE (v_row.raw_email IS NOT NULL AND lower(au.email) = lower(v_row.raw_email))
           OR (v_row.raw_phone IS NOT NULL AND au.phone = v_row.raw_phone)
        LIMIT 1;

        IF v_matched_id IS NULL THEN
            UPDATE import_staging_teachers SET match_status = 'new' WHERE id = v_row.id;
        ELSIF v_matched_name = v_row.raw_full_name THEN
            UPDATE import_staging_teachers SET match_status = 'identical', matched_user_id = v_matched_id WHERE id = v_row.id;
        ELSE
            UPDATE import_staging_teachers SET match_status = 'conflict', matched_user_id = v_matched_id WHERE id = v_row.id;
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION enforce_batch_fully_resolved(p_batch_id UUID, p_entity import_entity_enum)
RETURNS BOOLEAN AS $$
DECLARE
    v_pending_count INTEGER;
BEGIN
    IF p_entity = 'student' THEN
        SELECT count(*) INTO v_pending_count FROM import_staging_students
        WHERE batch_id = p_batch_id AND match_status = 'conflict' AND resolved_action = 'pending';
    ELSIF p_entity = 'teacher' THEN
        SELECT count(*) INTO v_pending_count FROM import_staging_teachers
        WHERE batch_id = p_batch_id AND match_status = 'conflict' AND resolved_action = 'pending';
    ELSE
        SELECT count(*) INTO v_pending_count FROM import_staging_classes
        WHERE batch_id = p_batch_id AND match_status = 'conflict' AND resolved_action = 'pending';
    END IF;

    RETURN v_pending_count = 0;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION commit_student_import_batch(p_batch_id UUID, p_actor_id UUID)
RETURNS TEXT AS $$
DECLARE
    v_row RECORD;
    v_account_id UUID;
BEGIN
    IF NOT enforce_batch_fully_resolved(p_batch_id, 'student') THEN
        RAISE EXCEPTION 'لا يمكن الاعتماد: ما زال هناك أسطر متصادمة بدون قرار مراجع بشري';
    END IF;

    SELECT account_id INTO v_account_id FROM import_batches WHERE id = p_batch_id;

    FOR v_row IN
        SELECT * FROM import_staging_students WHERE batch_id = p_batch_id
    LOOP
        IF v_row.resolved_action = 'ignore' OR
           (v_row.match_status = 'identical' AND v_row.resolved_action = 'pending') THEN
            CONTINUE;
        END IF;

        IF v_row.match_status = 'new' OR v_row.resolved_action = 'accept_new' AND v_row.matched_student_id IS NULL THEN
            INSERT INTO students (id, account_id, full_name)
            VALUES (gen_random_uuid(), v_account_id, COALESCE(v_row.resolved_final_name, v_row.raw_full_name));

        ELSIF v_row.resolved_action IN ('accept_new', 'manual_edit') AND v_row.matched_student_id IS NOT NULL THEN
            INSERT INTO name_change_log (account_id, entity_type, entity_id, field_name, old_value, new_value, changed_by, batch_id)
            SELECT v_account_id, 'student', s.id, 'full_name', s.full_name,
                   COALESCE(v_row.resolved_final_name, v_row.raw_full_name), p_actor_id, p_batch_id
            FROM students s WHERE s.id = v_row.matched_student_id;

            UPDATE students SET full_name = COALESCE(v_row.resolved_final_name, v_row.raw_full_name)
            WHERE id = v_row.matched_student_id;
        END IF;
    END LOOP;

    UPDATE import_batches SET status = 'committed', committed_at = now() WHERE id = p_batch_id;

    INSERT INTO audit_logs (account_id, user_id, action_type, table_name, new_value)
    VALUES (v_account_id, p_actor_id, 'insert', 'students',
            jsonb_build_object('event', 'bulk_import_commit', 'batch_id', p_batch_id, 'entity', 'student'));

    RETURN 'تم الاعتماد بنجاح';
END;
$$ LANGUAGE plpgsql;

-- ملاحظة: commit_teacher_import_batch و commit_class_import_batch تتبعان نفس
-- البنية بالضبط (تحقق enforce_batch_fully_resolved → أرشفة بـ name_change_log
-- عند التحديث → كتابة فعلية → تحديث حالة الدفعة → سطر بـ audit_logs)
-- لم تُكرَّر هون توفيراً للمساحة، لكنها بنفس القالب الحرفي أعلاه.

ALTER TABLE import_batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE import_staging_students ENABLE ROW LEVEL SECURITY;
ALTER TABLE import_staging_teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE import_staging_classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE name_change_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY import_batches_isolation ON import_batches
    USING (account_id = current_account_id());

CREATE POLICY import_batches_write ON import_batches
    FOR INSERT WITH CHECK (
        account_id = current_account_id()
        AND has_capability('records.import_manage')
    );

CREATE POLICY name_change_log_isolation ON name_change_log
    USING (account_id = current_account_id());

CREATE POLICY staging_students_isolation ON import_staging_students
    USING (batch_id IN (SELECT id FROM import_batches WHERE account_id = current_account_id()));
CREATE POLICY staging_teachers_isolation ON import_staging_teachers
    USING (batch_id IN (SELECT id FROM import_batches WHERE account_id = current_account_id()));
CREATE POLICY staging_classes_isolation ON import_staging_classes
    USING (batch_id IN (SELECT id FROM import_batches WHERE account_id = current_account_id()));
-- =====================================================================

-- =====================================================================
-- 08_grade_entry_conflict_resolution.sql
-- كشف الإدخال المكرر لعلامة امتحان بدقة مستوى المكوّن الواحد، مع قرار
-- منفصل لكل مكوّن: اعتماد الجديد / الإبقاء على القديم
--
-- مصحَّح: grade_history.resolution_method عمود NOT NULL بدون قيمة
-- افتراضية بالسكيما الحقيقية - نضبطه 'overwrite' لأنه استبدال مباشر
-- بالقيمة الجديدة. grades.status نضبطه 'confirmed' صراحة ليطابق سلوك
-- الإدخال المباشر بالواجهة (GradeEntryPanel.tsx).
-- =====================================================================

CREATE OR REPLACE FUNCTION check_existing_grade_components(
    p_exam_id UUID,
    p_student_id UUID
)
RETURNS TABLE (
    component_id UUID,
    component_name TEXT,
    existing_score NUMERIC,
    has_existing BOOLEAN
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        etc.id AS component_id,
        etc.component_name AS component_name,
        g.score AS existing_score,
        (g.id IS NOT NULL) AS has_existing
    FROM exam_type_components etc
    JOIN exams e ON e.exam_type_id = etc.exam_type_id
    LEFT JOIN grades g ON g.exam_id = p_exam_id
                       AND g.student_id = p_student_id
                       AND g.component_id = etc.id
    WHERE e.id = p_exam_id

    UNION ALL

    SELECT NULL::UUID, 'العلامة الكاملة', g.score, (g.id IS NOT NULL)
    FROM exams e
    LEFT JOIN grades g ON g.exam_id = p_exam_id
                       AND g.student_id = p_student_id
                       AND g.component_id IS NULL
    WHERE e.id = p_exam_id
      AND NOT EXISTS (
          SELECT 1 FROM exam_type_components etc2 WHERE etc2.exam_type_id = e.exam_type_id
      );
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION apply_grade_entry(
    p_exam_id UUID,
    p_student_id UUID,
    p_actor_id UUID,
    p_entries JSONB
)
RETURNS TEXT AS $$
DECLARE
    v_entry JSONB;
    v_component_id UUID;
    v_new_score NUMERIC;
    v_resolution TEXT;
    v_existing_id UUID;
    v_existing_score NUMERIC;
    v_applied_count INTEGER := 0;
    v_skipped_count INTEGER := 0;
BEGIN
    FOR v_entry IN SELECT * FROM jsonb_array_elements(p_entries)
    LOOP
        v_component_id := NULLIF(v_entry->>'component_id', '')::UUID;
        v_new_score := (v_entry->>'score')::NUMERIC;
        v_resolution := v_entry->>'resolution';

        SELECT id, score INTO v_existing_id, v_existing_score
        FROM grades
        WHERE exam_id = p_exam_id AND student_id = p_student_id
          AND component_id IS NOT DISTINCT FROM v_component_id;

        IF v_existing_id IS NULL THEN
            INSERT INTO grades (id, exam_id, student_id, component_id, score, entered_by, status)
            VALUES (gen_random_uuid(), p_exam_id, p_student_id, v_component_id, v_new_score, p_actor_id, 'confirmed');
            v_applied_count := v_applied_count + 1;

        ELSIF v_resolution = 'apply_new' THEN
            INSERT INTO grade_history (id, grade_id, old_score, new_score, resolution_method, changed_by, changed_at)
            VALUES (gen_random_uuid(), v_existing_id, v_existing_score, v_new_score, 'overwrite', p_actor_id, now());

            UPDATE grades SET score = v_new_score, entered_by = p_actor_id, status = 'confirmed'
            WHERE id = v_existing_id;
            v_applied_count := v_applied_count + 1;

        ELSE
            v_skipped_count := v_skipped_count + 1;
        END IF;
    END LOOP;

    INSERT INTO audit_logs (account_id, user_id, action_type, table_name, new_value)
    SELECT e.account_id, p_actor_id, 'update', 'grades',
           jsonb_build_object('event', 'grade_entry_with_conflict_check', 'exam_id', p_exam_id,
                               'student_id', p_student_id, 'applied', v_applied_count, 'skipped', v_skipped_count)
    FROM exams e WHERE e.id = p_exam_id;

    RETURN format('تم اعتماد %s مكوّن، وتجاهل %s', v_applied_count, v_skipped_count);
END;
$$ LANGUAGE plpgsql;

-- ملاحظة تطبيق بالواجهة (Web App):
-- 1) عند فتح شاشة إدخال علامة طالب لامتحان → استدعاء check_existing_grade_components
-- 2) لكل صف has_existing = true تُعرض القيمة القديمة بجانب حقل الإدخال الجديد
--    مع مفتاح تبديل صغير (اعتماد الجديد / الإبقاء على القديم) لكل مكوّن
-- 3) زر علوي واحد "تجاهل كل التعديلات" يصفّر كل الاختيارات دفعة وحدة
-- 4) الإرسال النهائي يستدعي apply_grade_entry بمصفوفة القرارات المجمّعة فقط
-- =====================================================================

-- =====================================================================
-- 09_submission_lock_and_reassignment.sql
-- قفل اعتماد نهائي على مستوى الامتحان (الناظر) + آلية نقل علامة مُدخلة
-- بالغلط تحت امتحان خاطئ لامتحانها الصحيح، مسموحة فقط قبل الاعتماد النهائي
--
-- مصحَّح ليطابق capabilities.key و audit_logs الحقيقية (account_id
-- إلزامي، action_type من ENUM محدود، old/new_value JSONB)
-- =====================================================================

INSERT INTO capabilities (key, label_ar, category)
VALUES ('grades.finalize_submission', 'اعتماد العلامات نهائياً لامتحان معيّن (قفل) أو إعادة فتحها للتصحيح', 'Admin')
ON CONFLICT (key) DO NOTHING;

ALTER TABLE exams ADD COLUMN IF NOT EXISTS is_locked_by_admin BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE exams ADD COLUMN IF NOT EXISTS locked_by UUID REFERENCES app_users(id);
ALTER TABLE exams ADD COLUMN IF NOT EXISTS locked_at TIMESTAMPTZ;

CREATE OR REPLACE FUNCTION enforce_grades_admin_lock()
RETURNS TRIGGER AS $$
DECLARE
    v_locked BOOLEAN;
    v_exam_id UUID;
BEGIN
    v_exam_id := COALESCE(NEW.exam_id, OLD.exam_id);
    SELECT is_locked_by_admin INTO v_locked FROM exams WHERE id = v_exam_id;

    IF v_locked THEN
        RAISE EXCEPTION 'تم اعتماد علامات هاد الامتحان نهائياً من الناظر - يلزم إعادة فتح الاعتماد أولاً قبل أي تعديل';
    END IF;

    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_enforce_grades_admin_lock
    BEFORE INSERT OR UPDATE OR DELETE ON grades
    FOR EACH ROW EXECUTE FUNCTION enforce_grades_admin_lock();

CREATE OR REPLACE FUNCTION finalize_exam_submission(p_exam_id UUID, p_actor_id UUID)
RETURNS TEXT AS $$
DECLARE
    v_account_id UUID;
BEGIN
    UPDATE exams SET is_locked_by_admin = true, locked_by = p_actor_id, locked_at = now()
    WHERE id = p_exam_id
    RETURNING account_id INTO v_account_id;

    INSERT INTO audit_logs (account_id, user_id, action_type, table_name, new_value)
    VALUES (v_account_id, p_actor_id, 'update', 'exams',
            jsonb_build_object('event', 'exam_grades_finalized', 'exam_id', p_exam_id));

    RETURN 'تم اعتماد علامات الامتحان نهائياً - الإدخال والتعديل مقفولان الآن';
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION reopen_exam_submission(p_exam_id UUID, p_actor_id UUID, p_reason TEXT DEFAULT NULL)
RETURNS TEXT AS $$
DECLARE
    v_account_id UUID;
BEGIN
    UPDATE exams SET is_locked_by_admin = false, locked_by = NULL, locked_at = NULL
    WHERE id = p_exam_id
    RETURNING account_id INTO v_account_id;

    INSERT INTO audit_logs (account_id, user_id, action_type, table_name, new_value)
    VALUES (v_account_id, p_actor_id, 'update', 'exams',
            jsonb_build_object('event', 'exam_grades_reopened', 'exam_id', p_exam_id, 'reason', p_reason));

    RETURN 'تم إعادة فتح الامتحان للتعديل';
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION reassign_grades_to_exam(
    p_student_ids UUID[],
    p_from_exam_id UUID,
    p_to_exam_id UUID,
    p_actor_id UUID
)
RETURNS TEXT AS $$
DECLARE
    v_from_locked BOOLEAN;
    v_to_locked BOOLEAN;
    v_conflict_count INTEGER;
    v_moved_count INTEGER;
    v_account_id UUID;
BEGIN
    SELECT is_locked_by_admin, account_id INTO v_from_locked, v_account_id FROM exams WHERE id = p_from_exam_id;
    SELECT is_locked_by_admin INTO v_to_locked FROM exams WHERE id = p_to_exam_id;

    IF v_from_locked OR v_to_locked THEN
        RAISE EXCEPTION 'لا يمكن نقل العلامات - أحد الامتحانين (المصدر أو الهدف) معتمد نهائياً من الناظر';
    END IF;

    SELECT count(*) INTO v_conflict_count
    FROM grades g_from
    JOIN grades g_to ON g_to.exam_id = p_to_exam_id
                     AND g_to.student_id = g_from.student_id
                     AND g_to.component_id IS NOT DISTINCT FROM g_from.component_id
    WHERE g_from.exam_id = p_from_exam_id
      AND g_from.student_id = ANY(p_student_ids);

    IF v_conflict_count > 0 THEN
        RAISE EXCEPTION 'يوجد % طالب عندهم أصلاً علامة بالامتحان الهدف - استخدم شاشة حل التعارض (apply_grade_entry) لهاد الحالات بدل النقل المباشر', v_conflict_count;
    END IF;

    UPDATE grades
    SET exam_id = p_to_exam_id
    WHERE exam_id = p_from_exam_id
      AND student_id = ANY(p_student_ids);

    GET DIAGNOSTICS v_moved_count = ROW_COUNT;

    INSERT INTO audit_logs (account_id, user_id, action_type, table_name, old_value, new_value)
    VALUES (v_account_id, p_actor_id, 'update', 'grades',
            jsonb_build_object('event', 'grades_reassigned_to_correct_exam', 'from_exam_id', p_from_exam_id),
            jsonb_build_object('to_exam_id', p_to_exam_id, 'students_moved', v_moved_count));

    RETURN format('تم نقل علامات %s طالب من الامتحان الخاطئ للامتحان الصحيح', v_moved_count);
END;
$$ LANGUAGE plpgsql;

-- ملاحظة تدفق العمل الكاملة:
-- 1) الناظر يفتح نافذة العلامات → المعلمون يدخلون
-- 2) طول ما الامتحان is_locked_by_admin = false، أي تصحيح حر:
--    - تعديل رقم عادي → apply_grade_entry (08)
--    - العلامة صارت تحت امتحان غلط بالكامل → reassign_grades_to_exam (هاد الملف)
-- 3) لما ينتهي المعلمون، الناظر يراجع ويعمل finalize_exam_submission → قفل تام
-- 4) أي خطأ يُكتشف بعد الاعتماد يتطلب reopen_exam_submission أولاً
-- =====================================================================

-- =====================================================================
-- 10_graduated_lock_tiers.sql
-- تطوير قفل الاعتماد من 09 (ثنائي: مقفول/مفتوح) إلى قفل متدرّج بمستويات
-- تطابق تسلسل الصلاحيات: الناظر العام → مساعد الناظر → الأستاذ
--
-- مصحَّح: capabilities.key، has_capability(p_code) بوسيط واحد (تتحقق
-- من جلسة auth.uid() الحالية مباشرة - v_actor_id هنا هو دائماً نفس
-- المستخدم صاحب الجلسة وقت إطلاق التريغر، فالنتيجة مطابقة)، audit_logs
-- بالشكل الحقيقي (account_id + ENUM + table_name + JSONB)
-- =====================================================================

-- 0) تفسير المستويات (lock_tier على exams):
--    2 = قفل كامل نهائي   → الكتابة مسموحة فقط لمن يملك grades.finalize_submission
--    1 = قفل جزئي         → الكتابة مسموحة لمن يملك grades.enter_privileged فأعلى
--    0 = مفتوح بالكامل    → الكتابة مسموحة لمن يملك grades.enter فأعلى (الوضع الطبيعي)

INSERT INTO capabilities (key, label_ar, category)
VALUES ('grades.enter_privileged', 'إدخال/تعديل العلامات أثناء وجود قفل جزئي من الناظر العام (طبقة مساعد الناظر)', 'Grades')
ON CONFLICT (key) DO NOTHING;

ALTER TABLE exams ADD COLUMN IF NOT EXISTS lock_tier SMALLINT NOT NULL DEFAULT 0
    CHECK (lock_tier IN (0, 1, 2));

UPDATE exams SET lock_tier = 2 WHERE is_locked_by_admin = true AND lock_tier = 0;

CREATE OR REPLACE FUNCTION get_actor_grade_authority_tier(p_actor_id UUID)
RETURNS SMALLINT AS $$
BEGIN
    IF has_capability('grades.finalize_submission') THEN
        RETURN 2;
    ELSIF has_capability('grades.enter_privileged') THEN
        RETURN 1;
    ELSIF has_capability('grades.enter') THEN
        RETURN 0;
    ELSE
        RETURN -1;
    END IF;
END;
$$ LANGUAGE plpgsql STABLE;

CREATE OR REPLACE FUNCTION enforce_grades_admin_lock()
RETURNS TRIGGER AS $$
DECLARE
    v_exam_id UUID;
    v_lock_tier SMALLINT;
    v_actor_tier SMALLINT;
    v_actor_id UUID := current_app_user_id();
BEGIN
    v_exam_id := COALESCE(NEW.exam_id, OLD.exam_id);
    SELECT lock_tier INTO v_lock_tier FROM exams WHERE id = v_exam_id;
    v_actor_tier := get_actor_grade_authority_tier(v_actor_id);

    IF v_actor_tier < v_lock_tier THEN
        RAISE EXCEPTION 'هاد الامتحان مقفول حالياً بمستوى أعلى من صلاحيتك - يلزم أن يرفع الناظر العام القفل درجة قبل ما تقدر تعدّل';
    END IF;

    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;
-- التريغر trg_enforce_grades_admin_lock من 09 يستخدم هالدالة تلقائياً (نفس الاسم)

CREATE OR REPLACE FUNCTION finalize_exam_submission(p_exam_id UUID, p_actor_id UUID)
RETURNS TEXT AS $$
DECLARE
    v_account_id UUID;
BEGIN
    UPDATE exams SET lock_tier = 2, is_locked_by_admin = true, locked_by = p_actor_id, locked_at = now()
    WHERE id = p_exam_id
    RETURNING account_id INTO v_account_id;

    INSERT INTO audit_logs (account_id, user_id, action_type, table_name, new_value)
    VALUES (v_account_id, p_actor_id, 'update', 'exams',
            jsonb_build_object('event', 'exam_grades_finalized', 'exam_id', p_exam_id, 'lock_tier', 2));

    RETURN 'تم اعتماد علامات الامتحان نهائياً - مقفول بالكامل حتى على مساعد الناظر';
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION lower_exam_lock_tier(p_exam_id UUID, p_actor_id UUID)
RETURNS TEXT AS $$
DECLARE
    v_current SMALLINT;
    v_new SMALLINT;
    v_account_id UUID;
BEGIN
    SELECT lock_tier, account_id INTO v_current, v_account_id FROM exams WHERE id = p_exam_id;

    IF v_current = 0 THEN
        RETURN 'الامتحان مفتوح بالكامل أصلاً - ما في قفل لرفعه';
    END IF;

    v_new := v_current - 1;

    UPDATE exams
    SET lock_tier = v_new,
        is_locked_by_admin = (v_new > 0),
        locked_by = CASE WHEN v_new = 0 THEN NULL ELSE locked_by END,
        locked_at = CASE WHEN v_new = 0 THEN NULL ELSE locked_at END
    WHERE id = p_exam_id;

    INSERT INTO audit_logs (account_id, user_id, action_type, table_name, old_value, new_value)
    VALUES (v_account_id, p_actor_id, 'update', 'exams',
            jsonb_build_object('previous_tier', v_current),
            jsonb_build_object('event', 'exam_lock_tier_lowered', 'exam_id', p_exam_id, 'new_tier', v_new));

    RETURN CASE
        WHEN v_new = 1 THEN 'تم رفع القفل درجة - مساعد الناظر فأعلى يقدر يعدّل الآن (الأستاذ لسا ممنوع)'
        ELSE 'تم رفع القفل بالكامل - الأستاذ يقدر يعدّل الآن كالمعتاد'
    END;
END;
$$ LANGUAGE plpgsql;

-- reopen_exam_submission من 09 تبقى موجودة كخيار "فتح فوري كامل" (طوارئ،
-- يقفز مباشرة لتير 0 بضغطة وحدة) - lower_exam_lock_tier هي المسار التدريجي
CREATE OR REPLACE FUNCTION reopen_exam_submission(p_exam_id UUID, p_actor_id UUID, p_reason TEXT DEFAULT NULL)
RETURNS TEXT AS $$
DECLARE
    v_account_id UUID;
BEGIN
    UPDATE exams SET lock_tier = 0, is_locked_by_admin = false, locked_by = NULL, locked_at = NULL
    WHERE id = p_exam_id
    RETURNING account_id INTO v_account_id;

    INSERT INTO audit_logs (account_id, user_id, action_type, table_name, new_value)
    VALUES (v_account_id, p_actor_id, 'update', 'exams',
            jsonb_build_object('event', 'exam_grades_reopened_fully', 'exam_id', p_exam_id, 'reason', p_reason));

    RETURN 'تم فتح الامتحان بالكامل فوراً (تجاوز التدرّج)';
END;
$$ LANGUAGE plpgsql;
-- =====================================================================

-- =====================================================================
-- 11_permission_matrix_rwm.sql
-- تنظيم الصلاحيات على مستوى مورد × إجراء (read/write/modify)
-- + قوالب أدوار جاهزة (الأدوار الخمسة المتفق عليها) + إمكانية إنشاء
-- موارد وأدوار جديدة بالكامل من لوحة التحكم بدون أي كود إضافي
--
-- ملاحظة مهمة: هاد الملف يطابق السكيما الحقيقية الموجودة على المشروع -
-- capabilities مفتاحها الأساسي key (نصي)، وليس id/code كما كان مفترضاً
-- بمسودة أولى. has_capability(p_code TEXT) توخذ وسيط واحد وتتحقق من
-- auth.uid() الجلسة الحالية مباشرة (مش actor_id مُمرَّر).
-- =====================================================================

CREATE TABLE permission_resources (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id  UUID REFERENCES accounts(id), -- NULL = مورد نظامي عام لكل الحسابات
    code        TEXT NOT NULL,
    label_ar    TEXT NOT NULL,
    is_system   BOOLEAN NOT NULL DEFAULT false,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (account_id, code)
);

CREATE TYPE capability_action_enum AS ENUM ('read', 'write', 'modify');

-- توسيع جدول capabilities الموجود بتصنيف مورد/إجراء - بدون حذف أو تعديل
-- أي عمود قديم، ولا أي صف قديم يُحذف
ALTER TABLE capabilities ADD COLUMN IF NOT EXISTS resource_id UUID REFERENCES permission_resources(id);
ALTER TABLE capabilities ADD COLUMN IF NOT EXISTS action capability_action_enum;
ALTER TABLE capabilities ADD COLUMN IF NOT EXISTS is_workflow_gate BOOLEAN NOT NULL DEFAULT false;

INSERT INTO permission_resources (code, label_ar, is_system) VALUES
    ('grades',        'العلامات',                true),
    ('roster',        'قوائم الطلاب والصفوف',    true),
    ('exams',         'الامتحانات وأنواعها',     true),
    ('reports',       'التقارير',                 true),
    ('config',        'إعدادات المدرسة',         true),
    ('users',         'المستخدمين والأدوار',     true),
    ('notifications', 'إشعارات الأهالي',         true),
    ('imports',       'الاستيراد الجماعي',       true),
    ('window',        'نافذة العلامات',           true)
ON CONFLICT (account_id, code) WHERE account_id IS NULL DO NOTHING;

-- ربط الصلاحيات القديمة بتصنيفها الجديد - بدون تغيير أكوادها (c.key يبقى
-- كما هو حتى تستمر كل الدوال القديمة تعمل بدون أي تعديل)
UPDATE capabilities c SET resource_id = r.id, action = 'write'
FROM permission_resources r WHERE r.code = 'grades' AND c.key = 'grades.enter';

UPDATE capabilities c SET resource_id = r.id, action = 'read'
FROM permission_resources r WHERE r.code = 'grades' AND c.key = 'grades.view_all';

UPDATE capabilities c SET resource_id = r.id, action = 'modify', is_workflow_gate = true
FROM permission_resources r WHERE r.code = 'grades' AND c.key = 'grades.finalize_submission';

UPDATE capabilities c SET resource_id = r.id, action = 'write', is_workflow_gate = true
FROM permission_resources r WHERE r.code = 'grades' AND c.key = 'grades.enter_privileged';

UPDATE capabilities c SET resource_id = r.id, action = 'write', is_workflow_gate = true
FROM permission_resources r WHERE r.code = 'grades' AND c.key = 'grades.enter_multi_component';

UPDATE capabilities c SET resource_id = r.id, action = 'modify'
FROM permission_resources r WHERE r.code = 'grades' AND c.key = 'grades.edit_others';

UPDATE capabilities c SET resource_id = r.id, action = 'modify'
FROM permission_resources r WHERE r.code = 'roster' AND c.key = 'roster.manage';

UPDATE capabilities c SET resource_id = r.id, action = 'read'
FROM permission_resources r WHERE r.code = 'reports' AND c.key IN ('reports.view', 'reports.export');

UPDATE capabilities c SET resource_id = r.id, action = 'modify'
FROM permission_resources r WHERE r.code = 'config' AND c.key = 'config.manage';

UPDATE capabilities c SET resource_id = r.id, action = 'modify'
FROM permission_resources r WHERE r.code = 'users' AND c.key = 'users.manage';

UPDATE capabilities c SET resource_id = r.id, action = 'write'
FROM permission_resources r WHERE r.code = 'notifications' AND c.key = 'notifications.send';

UPDATE capabilities c SET resource_id = r.id, action = 'modify'
FROM permission_resources r WHERE r.code = 'imports' AND c.key = 'records.import_manage';

UPDATE capabilities c SET resource_id = r.id, action = 'modify'
FROM permission_resources r WHERE r.code = 'window' AND c.key = 'window.toggle';

-- تعبئة أي فجوات بمصفوفة read/write/modify ما كانت موجودة قبل
INSERT INTO capabilities (key, label_ar, category, resource_id, action)
SELECT 'roster.view', 'الاطلاع على قوائم الطلاب والصفوف دون تعديل', 'Roster', id, 'read' FROM permission_resources WHERE code = 'roster'
ON CONFLICT (key) DO NOTHING;

INSERT INTO capabilities (key, label_ar, category, resource_id, action)
SELECT 'exams.view', 'الاطلاع على تعريف الامتحانات دون تعديل', 'Admin', id, 'read' FROM permission_resources WHERE code = 'exams'
ON CONFLICT (key) DO NOTHING;

INSERT INTO capabilities (key, label_ar, category, resource_id, action)
SELECT 'exams.manage', 'إنشاء/تعديل الامتحانات وأنواعها', 'Admin', id, 'modify' FROM permission_resources WHERE code = 'exams'
ON CONFLICT (key) DO NOTHING;

INSERT INTO capabilities (key, label_ar, category, resource_id, action)
SELECT 'imports.write', 'رفع ملف استيراد جديد (بدون صلاحية اعتماده نهائياً)', 'Admin', id, 'write' FROM permission_resources WHERE code = 'imports'
ON CONFLICT (key) DO NOTHING;

-- دالة إنشاء مورد جديد بالكامل - تولّد صلاحياته الثلاثة تلقائياً
CREATE OR REPLACE FUNCTION create_permission_resource(
    p_account_id UUID,
    p_code TEXT,
    p_label_ar TEXT,
    p_actor_id UUID
)
RETURNS UUID AS $$
DECLARE
    v_resource_id UUID;
BEGIN
    IF NOT has_capability('config.manage') THEN
        RAISE EXCEPTION 'لا تملك صلاحية إدارة الإعدادات (config.manage) اللازمة لإنشاء مورد صلاحيات جديد';
    END IF;

    IF p_account_id IS NULL THEN
        RAISE EXCEPTION 'p_account_id إلزامي - لا يمكن إنشاء مورد صلاحيات بدون حساب محدد (NULL يعني مورد نظامي ظاهر لكل الحسابات)';
    END IF;

    INSERT INTO permission_resources (account_id, code, label_ar, is_system)
    VALUES (p_account_id, p_code, p_label_ar, false)
    RETURNING id INTO v_resource_id;

    INSERT INTO capabilities (key, label_ar, category, resource_id, action) VALUES
        (p_code || '.read',   'الاطلاع على ' || p_label_ar, p_label_ar, v_resource_id, 'read'),
        (p_code || '.write',  'إضافة جديد ضمن ' || p_label_ar, p_label_ar, v_resource_id, 'write'),
        (p_code || '.modify', 'تعديل/حذف ضمن ' || p_label_ar, p_label_ar, v_resource_id, 'modify');

    INSERT INTO audit_logs (account_id, user_id, action_type, table_name, new_value)
    VALUES (p_account_id, p_actor_id, 'insert', 'permission_resources',
            jsonb_build_object('event', 'permission_resource_created', 'resource_code', p_code));

    RETURN v_resource_id;
END;
$$ LANGUAGE plpgsql;

-- قوالب الأدوار (Role Templates) - كل دور من الخمسة المتفق عليهم قالب
-- جاهز، وقابل إنشاء قوالب جديدة كاملة لأدوار غير موجودة أصلاً
CREATE TABLE role_templates (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id  UUID REFERENCES accounts(id), -- NULL = قالب نظامي متاح لكل الحسابات
    code        TEXT NOT NULL,
    label_ar    TEXT NOT NULL,
    is_system   BOOLEAN NOT NULL DEFAULT false,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (account_id, code)
);

-- الربط بـ capability_key (نصي) وليس capability_id - لأن capabilities
-- مفتاحها الأساسي key، لا يوجد عمود id على هذا الجدول
CREATE TABLE role_template_capabilities (
    template_id     UUID NOT NULL REFERENCES role_templates(id) ON DELETE CASCADE,
    capability_key  TEXT NOT NULL REFERENCES capabilities(key) ON DELETE CASCADE,
    PRIMARY KEY (template_id, capability_key)
);

INSERT INTO role_templates (code, label_ar, is_system) VALUES
    ('solo_teacher',    'معلّم مستقل (كامل الصلاحيات ضمن حدوده)', true),
    ('school_admin',    'الناظر العام',                            true),
    ('assistant_admin', 'مساعد الناظر العام',                      true),
    ('subject_teacher', 'معلم المادة',                              true),
    ('read_only_role',  'دور اطلاع فقط (مثل رئيس قسم)',            true)
ON CONFLICT (account_id, code) WHERE account_id IS NULL DO NOTHING;

INSERT INTO role_template_capabilities (template_id, capability_key)
SELECT t.id, c.key FROM role_templates t, capabilities c
WHERE t.code = 'solo_teacher'
  AND c.key IN ('grades.enter','grades.view_all','grades.enter_privileged','grades.finalize_submission',
                 'grades.enter_multi_component','roster.manage','roster.view','exams.manage','exams.view',
                 'reports.view','reports.export','config.manage','users.manage','notifications.send',
                 'records.import_manage','imports.write','window.toggle')
ON CONFLICT DO NOTHING;

INSERT INTO role_template_capabilities (template_id, capability_key)
SELECT t.id, c.key FROM role_templates t, capabilities c
WHERE t.code = 'school_admin'
  AND c.key IN ('grades.view_all','grades.finalize_submission','roster.manage','roster.view','exams.manage',
                 'exams.view','reports.view','reports.export','config.manage','users.manage',
                 'notifications.send','records.import_manage','imports.write','window.toggle')
ON CONFLICT DO NOTHING;

INSERT INTO role_template_capabilities (template_id, capability_key)
SELECT t.id, c.key FROM role_templates t, capabilities c
WHERE t.code = 'assistant_admin'
  AND c.key IN ('grades.enter','grades.view_all','grades.enter_privileged','roster.manage','roster.view',
                 'exams.view','reports.view','reports.export','notifications.send','imports.write')
ON CONFLICT DO NOTHING;

INSERT INTO role_template_capabilities (template_id, capability_key)
SELECT t.id, c.key FROM role_templates t, capabilities c
WHERE t.code = 'subject_teacher'
  AND c.key IN ('grades.enter','grades.enter_multi_component','roster.view','exams.view','reports.view')
ON CONFLICT DO NOTHING;

INSERT INTO role_template_capabilities (template_id, capability_key)
SELECT t.id, c.key FROM role_templates t, capabilities c
WHERE t.code = 'read_only_role'
  AND c.key IN ('grades.view_all','roster.view','exams.view','reports.view')
ON CONFLICT DO NOTHING;

CREATE OR REPLACE FUNCTION create_role_template(
    p_account_id UUID, p_code TEXT, p_label_ar TEXT, p_actor_id UUID
) RETURNS UUID AS $$
DECLARE v_id UUID;
BEGIN
    IF NOT has_capability('users.manage') THEN
        RAISE EXCEPTION 'لا تملك صلاحية users.manage اللازمة لإنشاء دور جديد';
    END IF;

    IF p_account_id IS NULL THEN
        RAISE EXCEPTION 'p_account_id إلزامي - لا يمكن إنشاء دور بدون حساب محدد (NULL يعني قالب نظامي ظاهر لكل الحسابات)';
    END IF;

    INSERT INTO role_templates (account_id, code, label_ar, is_system)
    VALUES (p_account_id, p_code, p_label_ar, false) RETURNING id INTO v_id;

    INSERT INTO audit_logs (account_id, user_id, action_type, table_name, new_value)
    VALUES (p_account_id, p_actor_id, 'insert', 'role_templates',
            jsonb_build_object('event', 'role_template_created', 'template_code', p_code));

    RETURN v_id;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION toggle_role_template_capability(
    p_template_id UUID, p_capability_key TEXT, p_grant BOOLEAN, p_actor_id UUID
) RETURNS TEXT AS $$
DECLARE v_account_id UUID;
BEGIN
    IF NOT has_capability('users.manage') THEN
        RAISE EXCEPTION 'لا تملك صلاحية users.manage اللازمة لتعديل مصفوفة الأدوار';
    END IF;

    SELECT account_id INTO v_account_id FROM app_users WHERE id = p_actor_id;

    IF p_grant THEN
        INSERT INTO role_template_capabilities (template_id, capability_key)
        VALUES (p_template_id, p_capability_key) ON CONFLICT DO NOTHING;
    ELSE
        DELETE FROM role_template_capabilities
        WHERE template_id = p_template_id AND capability_key = p_capability_key;
    END IF;

    INSERT INTO audit_logs (account_id, user_id, action_type, table_name, new_value)
    VALUES (v_account_id, p_actor_id, 'update', 'role_template_capabilities',
            jsonb_build_object('template_id', p_template_id, 'capability_key', p_capability_key, 'granted', p_grant));

    RETURN 'تم التحديث';
END;
$$ LANGUAGE plpgsql;

-- تطبيق قالب دور على مستخدم معيّن - يضيف الصلاحيات الناقصة فقط، ولا يلغي
-- أي صلاحية فردية إضافية سبق ومُنحت للمستخدم خارج القالب
CREATE OR REPLACE FUNCTION apply_role_template_to_user(
    p_user_id UUID, p_template_id UUID, p_actor_id UUID
) RETURNS TEXT AS $$
DECLARE v_account_id UUID;
BEGIN
    IF NOT has_capability('users.manage') THEN
        RAISE EXCEPTION 'لا تملك صلاحية users.manage اللازمة لتطبيق دور على مستخدم';
    END IF;

    SELECT account_id INTO v_account_id FROM app_users WHERE id = p_user_id;

    INSERT INTO user_capabilities (app_user_id, capability_key)
    SELECT p_user_id, rtc.capability_key
    FROM role_template_capabilities rtc
    WHERE rtc.template_id = p_template_id
    ON CONFLICT (app_user_id, capability_key) DO NOTHING;

    INSERT INTO audit_logs (account_id, user_id, action_type, table_name, new_value)
    VALUES (v_account_id, p_actor_id, 'update', 'user_capabilities',
            jsonb_build_object('event', 'role_template_applied', 'target_user', p_user_id, 'template_id', p_template_id));

    RETURN 'تم منح المستخدم كل صلاحيات القالب';
END;
$$ LANGUAGE plpgsql;

-- RLS على الجداول الجديدة - القراءة مفتوحة لكل عضو بالحساب (بما فيها
-- الصفوف النظامية)، الكتابة محصورة بصفوف حساب المستخدم نفسه + نفس
-- الصلاحية يلي تتحقق منها الدوال أعلاه (config.manage/users.manage) -
-- بدون هالشرط، أي مستخدم بالحساب كان يقدر يكتب مباشرة عبر Supabase
-- client من غير ما يمر على create_permission_resource/create_role_template
ALTER TABLE permission_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE role_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE role_template_capabilities ENABLE ROW LEVEL SECURITY;

CREATE POLICY permission_resources_select ON permission_resources
    FOR SELECT USING (account_id IS NULL OR account_id = current_account_id());

CREATE POLICY permission_resources_insert ON permission_resources
    FOR INSERT WITH CHECK (account_id = current_account_id() AND has_capability('config.manage'));

CREATE POLICY permission_resources_update ON permission_resources
    FOR UPDATE USING (account_id = current_account_id())
    WITH CHECK (account_id = current_account_id() AND has_capability('config.manage'));

CREATE POLICY permission_resources_delete ON permission_resources
    FOR DELETE USING (account_id = current_account_id() AND has_capability('config.manage'));

CREATE POLICY role_templates_select ON role_templates
    FOR SELECT USING (account_id IS NULL OR account_id = current_account_id());

CREATE POLICY role_templates_insert ON role_templates
    FOR INSERT WITH CHECK (account_id = current_account_id() AND has_capability('users.manage'));

CREATE POLICY role_templates_update ON role_templates
    FOR UPDATE USING (account_id = current_account_id())
    WITH CHECK (account_id = current_account_id() AND has_capability('users.manage'));

CREATE POLICY role_templates_delete ON role_templates
    FOR DELETE USING (account_id = current_account_id() AND has_capability('users.manage'));

CREATE POLICY role_template_capabilities_select ON role_template_capabilities
    FOR SELECT USING (template_id IN (
        SELECT id FROM role_templates WHERE account_id IS NULL OR account_id = current_account_id()
    ));

CREATE POLICY role_template_capabilities_insert ON role_template_capabilities
    FOR INSERT WITH CHECK (
        has_capability('users.manage')
        AND template_id IN (SELECT id FROM role_templates WHERE account_id = current_account_id())
    );

CREATE POLICY role_template_capabilities_delete ON role_template_capabilities
    FOR DELETE USING (
        has_capability('users.manage')
        AND template_id IN (SELECT id FROM role_templates WHERE account_id = current_account_id())
    );
-- =====================================================================

-- =====================================================================
-- 12_security_fixes.sql
-- تصحيحات أمان اكتُشفت أثناء تنفيذ 07-11 على القاعدة الحقيقية عبر
-- Supabase Advisors - كلاهما موجود من قبل 07-11 وليس ناتج عنهما،
-- لكن أولهما كان سيمنع ملف 08 من العمل فعلياً وقت التشغيل:
--
-- 1) grade_history كانت RLS enabled عليها بدون أي policy إطلاقاً - يعني
--    أي INSERT من apply_grade_entry (08) كان سيُرفض تلقائياً لأي مستخدم
--    عادي (RLS enabled + no policy = رفض تام لغير service_role).
--
-- 2) الـ 6 views (v_grade_report وغيرها) كانت SECURITY DEFINER ضمنياً
--    (سلوك Postgres الافتراضي) - تشتغل بصلاحيات مالك الـ view متجاوزة
--    RLS، يعني أي مستخدم موثّق كان يقدر يشوف بيانات كل الحسابات عبر
--    هالـ views لا بيانات حسابه فقط. Supabase's linter صنّف هاي ERROR.
-- =====================================================================

CREATE POLICY grade_history_read ON grade_history
    FOR SELECT USING (grade_id IN (
        SELECT g.id FROM grades g JOIN exams e ON e.id = g.exam_id WHERE e.account_id = current_account_id()
    ));

CREATE POLICY grade_history_insert ON grade_history
    FOR INSERT WITH CHECK (grade_id IN (
        SELECT g.id FROM grades g JOIN exams e ON e.id = g.exam_id WHERE e.account_id = current_account_id()
    ));

ALTER VIEW v_exam_effective_score SET (security_invoker = true);
ALTER VIEW v_student_term_average SET (security_invoker = true);
ALTER VIEW v_student_class_rank SET (security_invoker = true);
ALTER VIEW v_class_term_summary SET (security_invoker = true);
ALTER VIEW v_school_term_summary SET (security_invoker = true);
ALTER VIEW v_grade_report SET (security_invoker = true);
-- =====================================================================
