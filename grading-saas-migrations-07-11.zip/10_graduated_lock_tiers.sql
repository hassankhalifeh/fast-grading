-- =====================================================================
-- 10_graduated_lock_tiers.sql
-- تطوير قفل الاعتماد من 09 (ثنائي: مقفول/مفتوح) إلى قفل متدرّج بمستويات
-- تطابق تسلسل الصلاحيات: الناظر العام → مساعد الناظر → الأستاذ
-- الناظر العام يرفع القفل درجة درجة (تدريجياً)، لا يقفز مباشرة لصلاحية الأستاذ
-- إضافي بالكامل فوق 09 - يستبدل منطق التريغر فقط، لا يحذف شي
-- =====================================================================

-- ---------------------------------------------------------------------
-- 0) تفسير المستويات (lock_tier على exams):
--    2 = قفل كامل نهائي   → الكتابة مسموحة فقط لمن يملك grades.finalize_submission (الناظر العام)
--    1 = قفل جزئي         → الكتابة مسموحة لمن يملك grades.enter_privileged فأعلى (مساعد الناظر فأعلى)
--    0 = مفتوح بالكامل    → الكتابة مسموحة لمن يملك grades.enter فأعلى (الأستاذ فأعلى) - الوضع الطبيعي
-- ---------------------------------------------------------------------

-- صلاحية الطبقة الوسطى (مساعد الناظر العام) - جديدة ضمن كتالوج 04
INSERT INTO capabilities (code, description)
VALUES ('grades.enter_privileged', 'إدخال/تعديل العلامات أثناء وجود قفل جزئي من الناظر العام (طبقة مساعد الناظر)')
ON CONFLICT (code) DO NOTHING;

ALTER TABLE exams ADD COLUMN IF NOT EXISTS lock_tier SMALLINT NOT NULL DEFAULT 0
    CHECK (lock_tier IN (0, 1, 2));

-- تحديث القيم القديمة القادمة من 09 (is_locked_by_admin) لتتوافق مع النظام الجديد
UPDATE exams SET lock_tier = 2 WHERE is_locked_by_admin = true AND lock_tier = 0;

-- ---------------------------------------------------------------------
-- 1) دالة تحدد أعلى مستوى سلطة يملكه المستخدم على العلامات
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION get_actor_grade_authority_tier(p_actor_id UUID)
RETURNS SMALLINT AS $$
BEGIN
    IF has_capability(p_actor_id, 'grades.finalize_submission') THEN
        RETURN 2;
    ELSIF has_capability(p_actor_id, 'grades.enter_privileged') THEN
        RETURN 1;
    ELSIF has_capability(p_actor_id, 'grades.enter') THEN
        RETURN 0;
    ELSE
        RETURN -1; -- ما عنده أي صلاحية إدخال أصلاً
    END IF;
END;
$$ LANGUAGE plpgsql STABLE;

-- ---------------------------------------------------------------------
-- 2) استبدال منطق التريغر: الكتابة مسموحة فقط إذا سلطة المستخدم >= قفل الامتحان
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION enforce_grades_admin_lock()
RETURNS TRIGGER AS $$
DECLARE
    v_exam_id UUID;
    v_lock_tier SMALLINT;
    v_actor_tier SMALLINT;
    v_actor_id UUID := current_app_user_id(); -- نفس دالة السياق المستخدمة بباقي RLS
BEGIN
    v_exam_id := COALESCE(NEW.exam_id, OLD.exam_id);
    SELECT lock_tier INTO v_lock_tier FROM exams WHERE id = v_exam_id;
    v_actor_tier := get_actor_grade_authority_tier(v_actor_id);

    IF v_actor_tier < v_lock_tier THEN
        RAISE EXCEPTION 'هاد الامتحان مقفول حالياً بمستوى أعلى من صلاحيتك - يلزم أن يرفع الناظر العام القفل درجة قبل ما تقدر تعدّل';
    END IF;

    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;
-- التريغر trg_enforce_grades_admin_lock من 09 يستخدم هالدالة تلقائياً (نفس الاسم)

-- ---------------------------------------------------------------------
-- 3) اعتماد نهائي = قفل كامل مباشرة على أعلى درجة (2)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION finalize_exam_submission(p_exam_id UUID, p_actor_id UUID)
RETURNS TEXT AS $$
BEGIN
    UPDATE exams
    SET lock_tier = 2, is_locked_by_admin = true, locked_by = p_actor_id, locked_at = now()
    WHERE id = p_exam_id;

    INSERT INTO audit_logs (user_id, action_type, old_value, new_value)
    VALUES (p_actor_id, 'exam_grades_finalized', NULL,
            jsonb_build_object('exam_id', p_exam_id, 'lock_tier', 2)::text);

    RETURN 'تم اعتماد علامات الامتحان نهائياً - مقفول بالكامل حتى على مساعد الناظر';
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- 4) رفع القفل درجة واحدة فقط (التدرّج المطلوب) - يتطلب grades.finalize_submission
--    2→1: يسمح الآن لمساعد الناظر (وأعلى) بالتعديل، الأستاذ لسا ممنوع
--    1→0: يسمح الآن للأستاذ بالتعديل - الوضع الطبيعي الكامل
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION lower_exam_lock_tier(p_exam_id UUID, p_actor_id UUID)
RETURNS TEXT AS $$
DECLARE
    v_current SMALLINT;
    v_new SMALLINT;
BEGIN
    SELECT lock_tier INTO v_current FROM exams WHERE id = p_exam_id;

    IF v_current = 0 THEN
        RETURN 'الامتحان مفتوح بالكامل أصلاً - ما في قفل لرفعه';
    END IF;

    v_new := v_current - 1;

    UPDATE exams
    SET lock_tier = v_new,
        is_locked_by_admin = (v_new > 0), -- يبقى true طالما في أي درجة قفل
        locked_by = CASE WHEN v_new = 0 THEN NULL ELSE locked_by END,
        locked_at = CASE WHEN v_new = 0 THEN NULL ELSE locked_at END
    WHERE id = p_exam_id;

    INSERT INTO audit_logs (user_id, action_type, old_value, new_value)
    VALUES (p_actor_id, 'exam_lock_tier_lowered',
            jsonb_build_object('previous_tier', v_current)::text,
            jsonb_build_object('exam_id', p_exam_id, 'new_tier', v_new)::text);

    RETURN CASE
        WHEN v_new = 1 THEN 'تم رفع القفل درجة - مساعد الناظر فأعلى يقدر يعدّل الآن (الأستاذ لسا ممنوع)'
        ELSE 'تم رفع القفل بالكامل - الأستاذ يقدر يعدّل الآن كالمعتاد'
    END;
END;
$$ LANGUAGE plpgsql;

-- ملاحظة: دالة reopen_exam_submission من 09 تبقى موجودة كخيار "فتح فوري كامل"
-- (طوارئ، يقفز مباشرة لتير 0 بضغطة وحدة) - lower_exam_lock_tier هي المسار
-- التدريجي المطلوب بشكل افتراضي بالواجهة، وreopen_exam_submission تبقى
-- متاحة بس كخيار ثانوي "تجاوز وفتح فوراً" لو الناظر العام حبّ يستخدمها
CREATE OR REPLACE FUNCTION reopen_exam_submission(p_exam_id UUID, p_actor_id UUID, p_reason TEXT DEFAULT NULL)
RETURNS TEXT AS $$
BEGIN
    UPDATE exams
    SET lock_tier = 0, is_locked_by_admin = false, locked_by = NULL, locked_at = NULL
    WHERE id = p_exam_id;

    INSERT INTO audit_logs (user_id, action_type, old_value, new_value)
    VALUES (p_actor_id, 'exam_grades_reopened_fully',
            NULL, jsonb_build_object('exam_id', p_exam_id, 'reason', p_reason)::text);

    RETURN 'تم فتح الامتحان بالكامل فوراً (تجاوز التدرّج)';
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- 5) apply_default_capabilities (من 04) بحاجة سطر إضافي بسيط:
--    منح grades.enter_privileged تلقائياً لدور "مساعد الناظر العام" فقط
--    (لم يُدرج هون الجسم الكامل للدالة تفادياً لتكرار كود 04 - إضافة سطر
--    INSERT واحد داخلها لدور assistant_admin كافي، حسب بنية الدالة الأصلية)
-- =====================================================================
