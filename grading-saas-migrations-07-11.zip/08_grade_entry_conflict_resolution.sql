-- =====================================================================
-- 08_grade_entry_conflict_resolution.sql
-- كشف الإدخال المكرر لعلامة امتحان (نفس الطالب/نفس الامتحان) بدقة
-- مستوى المكوّن الواحد (تحريري/شفهي/كويز..)، مع قرار منفصل لكل مكوّن:
-- اعتماد الجديد / الإبقاء على القديم - أو تجاهل الكل دفعة واحدة من الواجهة
-- إضافي بالكامل - لا يعدّل أي جدول من 01-07
-- =====================================================================

CREATE TYPE grade_conflict_resolution_enum AS ENUM ('apply_new', 'keep_old');

-- ---------------------------------------------------------------------
-- 1) فحص مسبق: يُستدعى فور ما الأستاذ يفتح شاشة إدخال علامة طالب
--    بامتحان معيّن - يرجع كل مكوّن مع القيمة القديمة (إذا موجودة) عشان
--    الواجهة تعرضها جنب القيمة الجديدة قبل أي إرسال فعلي
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION check_existing_grade_components(
    p_exam_id UUID,
    p_student_id UUID
)
RETURNS TABLE (
    component_id UUID,
    component_name TEXT,
    existing_score NUMERIC,
    has_existing BOOLEAN
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        etc.id AS component_id,
        etc.name AS component_name,
        g.score AS existing_score,
        (g.id IS NOT NULL) AS has_existing
    FROM exam_type_components etc
    JOIN exams e ON e.exam_type_id = etc.exam_type_id
    LEFT JOIN grades g ON g.exam_id = p_exam_id
                       AND g.student_id = p_student_id
                       AND g.component_id = etc.id
    WHERE e.id = p_exam_id

    UNION ALL

    -- حالة الامتحان البسيط بدون مكوّنات فرعية (علامة واحدة مسطحة)
    SELECT NULL::UUID, 'العلامة الكاملة', g.score, (g.id IS NOT NULL)
    FROM exams e
    LEFT JOIN grades g ON g.exam_id = p_exam_id
                       AND g.student_id = p_student_id
                       AND g.component_id IS NULL
    WHERE e.id = p_exam_id
      AND NOT EXISTS (
          SELECT 1 FROM exam_type_components etc2 WHERE etc2.exam_type_id = e.exam_type_id
      );
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- 2) الإرسال الفعلي - بعد ما الأستاذ ياخذ قرار لكل مكوّن فيه تصادم
--    p_entries: JSONB array بالشكل
--    [{"component_id": "...", "score": 17.5, "resolution": "apply_new"}, ...]
--    component_id يكون null لحالة العلامة المسطحة بدون مكوّنات
--    resolution إلزامي فقط للمكوّنات يلي عندها has_existing = true
--    (المكوّنات الجديدة كلياً تُدخل مباشرة بدون داعي لحقل resolution)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION apply_grade_entry(
    p_exam_id UUID,
    p_student_id UUID,
    p_actor_id UUID,
    p_entries JSONB
)
RETURNS TEXT AS $$
DECLARE
    v_entry JSONB;
    v_component_id UUID;
    v_new_score NUMERIC;
    v_resolution TEXT;
    v_existing_id UUID;
    v_existing_score NUMERIC;
    v_applied_count INTEGER := 0;
    v_skipped_count INTEGER := 0;
BEGIN
    FOR v_entry IN SELECT * FROM jsonb_array_elements(p_entries)
    LOOP
        v_component_id := NULLIF(v_entry->>'component_id', '')::UUID;
        v_new_score := (v_entry->>'score')::NUMERIC;
        v_resolution := v_entry->>'resolution'; -- may be NULL if no conflict existed

        SELECT id, score INTO v_existing_id, v_existing_score
        FROM grades
        WHERE exam_id = p_exam_id AND student_id = p_student_id
          AND component_id IS NOT DISTINCT FROM v_component_id;

        IF v_existing_id IS NULL THEN
            -- لا يوجد تصادم أصلاً: إدخال مباشر
            INSERT INTO grades (id, exam_id, student_id, component_id, score, entered_by)
            VALUES (gen_random_uuid(), p_exam_id, p_student_id, v_component_id, v_new_score, p_actor_id);
            v_applied_count := v_applied_count + 1;

        ELSIF v_resolution = 'apply_new' THEN
            -- المستخدم اختار اعتماد الجديد لهاد المكوّن تحديداً
            INSERT INTO grade_history (id, grade_id, old_score, new_score, changed_by, changed_at)
            VALUES (gen_random_uuid(), v_existing_id, v_existing_score, v_new_score, p_actor_id, now());

            UPDATE grades SET score = v_new_score, entered_by = p_actor_id
            WHERE id = v_existing_id;
            v_applied_count := v_applied_count + 1;

        ELSE
            -- 'keep_old' أو تجاهل كامل من الواجهة (ما بترسل هاد العنصر أصلاً
            -- إذا اختار المستخدم "تجاهل الكل" - الواجهة ببساطة ما بتضيفه بالمصفوفة)
            v_skipped_count := v_skipped_count + 1;
        END IF;
    END LOOP;

    INSERT INTO audit_logs (user_id, action_type, old_value, new_value)
    VALUES (p_actor_id, 'grade_entry_with_conflict_check',
            NULL,
            jsonb_build_object('exam_id', p_exam_id, 'student_id', p_student_id,
                                'applied', v_applied_count, 'skipped', v_skipped_count)::text);

    RETURN format('تم اعتماد %s مكوّن، وتجاهل %s', v_applied_count, v_skipped_count);
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- ملاحظة تطبيق بالواجهة (Web App):
-- 1) عند فتح شاشة إدخال علامة طالب لامتحان → استدعاء check_existing_grade_components
-- 2) لكل صف has_existing = true تُعرض القيمة القديمة بجانب حقل الإدخال الجديد
--    مع مفتاح تبديل صغير (اعتماد الجديد / الإبقاء على القديم) لكل مكوّن
-- 3) زر علوي واحد "تجاهل كل التعديلات" يصفّر كل الاختيارات دفعة وحدة
--    (يكافئ ببساطة عدم إرسال أي مكوّن كان resolution له غير apply_new)
-- 4) الإرسال النهائي يستدعي apply_grade_entry بمصفوفة القرارات المجمّعة فقط
-- =====================================================================
